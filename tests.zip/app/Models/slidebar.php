<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class slidebar extends Model
{
    protected  $table ='lv2_slidebars';
    protected $guarded =[];
}
