<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CT_tag_diadiem extends Model
{
    //
}
